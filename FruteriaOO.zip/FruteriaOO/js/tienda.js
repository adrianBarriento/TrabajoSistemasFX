window.onload=cargarAjax;
let total = 0;
function cargarAjax(){
  var req = new XMLHttpRequest();
  req.open('GET', 'tienda.json', true);
  req.onreadystatechange = function (aEvt) {
    if (req.readyState == 4) {
      if(req.status == 200){
        let datos = req.responseText;
        let productos = JSON.parse(datos);

        let root = document.querySelector("#idProductos");
        for(let p of productos){
            let card = document.createElement("div");
            card.setAttribute("class", "col-12 col-sm-6 col-md-4 col-lg-3 p-2")
            let div = document.createElement("div");
            div.setAttribute("class", "card");
            root.appendChild(card);
            card.appendChild(div);    
            let foto = document.createElement("img");
            foto.setAttribute("src", p.foto);
            foto.setAttribute("class","card-img-top");
            div.appendChild(foto);

            let divBody = document.createElement("div");
            divBody.setAttribute("class", "card-body");
            div.appendChild(divBody);

            let titulo = document.createElement("h5");
            titulo.setAttribute("class", "card-title");
            titulo.innerHTML = p.nombre;
            divBody.appendChild(titulo);

            let procedencia = document.createElement("p");
            procedencia.setAttribute("class" ,"card-text");
            procedencia.innerHTML= p.procedencia;
            divBody.appendChild(procedencia);

            let precio = document.createElement("p");
            precio.setAttribute("class", "card-text");
            precio.innerHTML = p.precio+" €";
            divBody.appendChild(precio);

            let boton = document.createElement("a");
            boton.setAttribute("class", "btn btn-warning");
            boton.innerHTML = "Añadir a la cesta";
            divBody.appendChild(boton);

            boton.addEventListener("click", ()=>{
                sumar(p.nombre, p.precio);
            })
        
        } 
        
        console.log(productos)
      }else{
        dump("Error loading page\n");
      }
    }
  };
  req.send(null);
}

function sumar(nombre, precio){
  let producto = document.createElement("p");
  producto.innerText=nombre + " " + precio + "€";
  document.getElementById("cesta").insertBefore(producto, document.getElementById("total"));
  document.getElementById("total").innerHTML= "Total compra: " + ((total+=precio).toFixed(2));
}